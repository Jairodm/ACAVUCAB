ALTER SEQUENCE Tipo_de_cerveza_Codigo_tipo_cerveza_seq RESTART WITH 41 INCREMENT BY 1;
ALTER SEQUENCE Caracteristica_Codigo_caracteristica_seq RESTART WITH 11  INCREMENT BY 1;
ALTER SEQUENCE Caracteristica_y_Tipo_de_Cerveza_Codigo_caracteristica_tcer_seq RESTART WITH 121 INCREMENT BY 1;
ALTER SEQUENCE Comentario_Codigo_comentario_seq RESTART WITH 121 INCREMENT BY 1;
ALTER SEQUENCE Ingrediente_Codigo_ingrediente_seq RESTART WITH 8 INCREMENT BY 1;
ALTER SEQUENCE Receta_Codigo_receta_seq RESTART WITH 9 INCREMENT BY 1;
ALTER SEQUENCE Cerveza_Codigo_cerveza_seq RESTART WITH 81 INCREMENT BY 1;
ALTER SEQUENCE Rol_Codigo_rol_seq RESTART WITH 6 INCREMENT BY 1;
ALTER SEQUENCE Usuario_Codigo_usuario_seq RESTART WITH 69  INCREMENT BY 1;
ALTER SEQUENCE Presupuesto_Codigo_presupuesto_seq RESTART WITH 11  INCREMENT BY 1;
ALTER SEQUENCE Detalle_presupuesto_Codigo_detalle_presupuesto_seq RESTART WITH 21  INCREMENT BY 1;
ALTER SEQUENCE Cuota_afiliacion_Codigo_cuota_seq RESTART WITH 13 INCREMENT by 1;
ALTER SEQUENCE Proveedor_y_cuota_Codigo_proveedor_y_cuota_seq RESTART WITH 241 INCREMENT BY 1;
ALTER SEQUENCE Evento_Codigo_evento_seq RESTART WITH 26 increment by 1;
ALTER SEQUENCE Persona_contacto_Codigo_persona_contacto_seq RESTART WITH 6 INCREMENT BY 1;
ALTER SEQUENCE Telefono_Codigo_telefono_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Correo_electronico_Codigo_correo_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Divisa_Codigo_divisa_seq RESTART WITH 8 INCREMENT BY 1;
ALTER SEQUENCE Historico_divisa_Codigo_historico_divisa_seq RESTART WITH 12 INCREMENT BY 1;
ALTER SEQUENCE Metodo_pago_Codigo_metodo_pago_seq RESTART WITH 144 INCREMENT BY 1;
ALTER SEQUENCE Cargo_Codigo_cargo_seq RESTART WITH 8 INCREMENT BY 1;
ALTER SEQUENCE Privilegio_Codigo_privilegio_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Rol_y_privilegio_Codigo_rol_privilegio_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Beneficio_Codigo_beneficio_seq RESTART WITH 18 INCREMENT BY 1;
ALTER SEQUENCE Vacacion_Codigo_vacacion_seq RESTART WITH 22 INCREMENT BY 1;
ALTER SEQUENCE Asistencia_Codigo_asistencia_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Horario_Codigo_horario_seq RESTART WITH 11 INCREMENT BY 1;
ALTER SEQUENCE Oferta_Codigo_oferta_seq RESTART WITH 1 INCREMENT BY 1;

ALTER SEQUENCE Asistencia_Codigo_asistencia_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Estatus_Codigo_estatus_seq RESTART WITH 3 INCREMENT BY 1;
ALTER SEQUENCE Venta_Numero_factura_seq RESTART WITH 100 INCREMENT BY 1;
ALTER SEQUENCE Estatus_y_venta_Codigo_estatus_y_venta_seq RESTART WITH 51 INCREMENT by 1;
ALTER SEQUENCE Orden_compra_Codigo_orden_compra_seq RESTART WITH 7 INCREMENT BY 1;
ALTER SEQUENCE Estatus_y_orden_Codigo_estatus_seq RESTART WITH 7 INCREMENT BY 1;
ALTER SEQUENCE Evento_y_proveedor_Codigo_evento_proveedor_seq RESTART WITH 1 INCREMENT BY 1;

ALTER SEQUENCE Horario_y_empleado_Codigo_horario_y_empleado_seq RESTART WITH 101 INCREMENT BY 1; 
ALTER SEQUENCE Pasillo_Codigo_pasillo_seq RESTART WITH 11 INCREMENT BY 1;
ALTER SEQUENCE Anaquel_Codigo_anaquel_seq RESTART WITH 50 INCREMENT BY 1;
ALTER SEQUENCE Detalle_compra_Codigo_detalle_compra_seq RESTART WITH 81 INCREMENT BY 1;
ALTER SEQUENCE Detalle_venta_Codigo_detalle_venta_seq RESTART WITH 200 INCREMENT BY 1;
ALTER SEQUENCE Inventario_evento_Codigo_inventario_evento_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Oferta_y_cerveza_Codigo_oferta_y_cerveza_seq RESTART WITH 1 INCREMENT BY 1;
ALTER SEQUENCE Inventario_Codigo_inventario_seq RESTART WITH 281 INCREMENT BY 1;
ALTER SEQUENCE Carrito_Codigo_carrito_seq RESTART WITH 11 INCREMENT BY 1;


